Mido Egypt Tours — Final Website Package (English)

Contents:
- index.html (single-page luxury site)
- style.css (styling)
- README.txt (this file)

Quick deploy (Netlify Drop):
1. Open https://app.netlify.com/drop
2. Tap Upload and choose the file 'index.html' from this package (or upload the full ZIP).
3. Netlify will deploy and give your public URL in seconds.

Quick deploy (Vercel):
1. Open https://vercel.com and log in with your Google account.
2. Click "New Project" → "Import" → choose "Deploy Manually" and upload the project files.
3. Vercel will deploy and provide a domain (you can rename it).

WhatsApp booking configured to +20 101 582 6616.
If you need help uploading from mobile, tell me which phone (Android/iPhone) and I will send precise steps.
